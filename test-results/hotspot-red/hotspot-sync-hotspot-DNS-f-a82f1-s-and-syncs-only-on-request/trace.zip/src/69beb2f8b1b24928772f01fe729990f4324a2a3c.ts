import { expect, test } from '@playwright/test'

test('hotspot DNS failure preserves pending records and syncs only on request', async ({ page }) => {
  test.skip(!process.env.VITE_SUPABASE_URL, 'Run with mock Supabase Vite environment variables.')
  let requests = 0
  const errors: string[] = []
  page.on('pageerror', error => errors.push(error.message))
  await page.route('http://supabase.test/**', route => {
    requests += 1
    return route.abort('namenotresolved')
  })
  await page.addInitScript(() => {
    localStorage.setItem('tunaeye-installed', 'true')
    localStorage.setItem('tunaeye-grader-name', 'Maria Santos')
    localStorage.setItem('tunaeye-records', JSON.stringify([{
      id: 'hotspot-record', sessionId: 'hotspot-session', timestamp: Date.now(), time: 'Now', grader: 'Maria Santos', sample: 'Sashibo core', fish: 'Fish 1', weight: '42 kg', grade: 'A', status: 'Complete',
      transaction: { currency: 'PHP', unitRatePerKg: 420, amount: 17640, syncState: 'pending' },
    }]))
  })
  await page.goto('/kiosk/grader-dashboard')
  await expect(page.getByRole('button', { name: 'Sync now' })).toBeVisible()
  const original = await page.evaluate(() => localStorage.getItem('tunaeye-records'))
  await page.evaluate(() => window.dispatchEvent(new Event('online')))
  // Allow any unintended reconnect handler's authentication request to begin.
  await page.waitForTimeout(300)
  expect(requests).toBe(0)
  await page.getByRole('button', { name: 'Sync now' }).click()
  await expect(page.getByText(/Cloud is unreachable/)).toBeVisible()
  await expect(page.getByText(/Pi Wi-Fi can work without internet/)).toBeVisible()
  expect(requests).toBeGreaterThan(0)
  expect(await page.evaluate(() => localStorage.getItem('tunaeye-records'))).toBe(original)
  expect(errors).toEqual([])
  await page.getByRole('button', { name: 'Understood' }).click()
  await page.getByRole('button', { name: 'Start grading', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Select specimens' })).toBeVisible()
})
